import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpCommonServiceCallService } from '../http-common-service-call.service';
declare var showToastMessage: any;
@Component({
  selector: 'app-navmenu',
  templateUrl: './navmenu.component.html',
  styleUrls: ['./navmenu.component.css'],
})
export class NavmenuComponent implements OnInit {
  public token = sessionStorage.getItem('authToken');
  public menuItems: [];
  constructor(
    private commonServiceCall: HttpCommonServiceCallService,
    private router: Router
  ) {}

  ngOnInit() {
    this.getMenuList();
  }

  logout() {
    var req = 'login/logout';
    this.commonServiceCall.postResponsePromise(req).subscribe((resp) => {
      console.log(resp);
      localStorage.clear();
      this.commonServiceCall.userCredential = {};
      this.router.navigateByUrl('/login');
      sessionStorage.setItem('isLoggedIn', 'false');
      sessionStorage.setItem('userCredential','');
      if (resp.status) {
        // this.commonServiceCall.authToken = '';
        
      } else {
      }
    });
  }

  getMenuList() {
    var roleId = this.commonServiceCall.roleId;
    if(roleId == undefined){
      this.router.navigateByUrl('/login');
      return;
    }
    console.log('menu role id', roleId);
    var req = 'menu/findAllMenu/' + roleId;
    this.commonServiceCall.getMenuItems(req).subscribe((data) => {
      if (data.status) {
      this.menuItems = data.resp;
      console.log('', this.menuItems);
      } else {
        showToastMessage('Your session has been expired. Please login again');
        this.router.navigateByUrl('/login');
      }
    });
  }


  gotoPage(pageName){
    console.log(pageName);

    if(pageName == 'SubMenu Rights'){
      this.router.navigateByUrl('/accessSubMenuRight');
    }
    else if(pageName == 'customizeMenu'){
      this.router.navigateByUrl('/accessCustomizeMenu');
    }
    else if(pageName == 'Menu Rights'){
      this.router.navigateByUrl('/accessMenuRight');
    }
    else if(pageName == 'User Administration'){
      this.router.navigateByUrl('/adminstration');
    }
    else if(pageName == 'WalletPoints'){
      this.router.navigateByUrl('/adminWalletPoints');
    }
    else if(pageName == 'notifications'){
      this.router.navigateByUrl('/adminNotification');
    }
    else if(pageName == 'Omnichannelrequest'){
      this.router.navigateByUrl('/adminOmniChannelReq');
    }
    else if(pageName == 'Omni Channel Report'){
      this.router.navigateByUrl('/adminOmniChannelReport');
    }
    else if(pageName == 'Charges/Commission'){
      this.router.navigateByUrl('/adminChargesComminsion');
    }
    else if(pageName == 'Agent Transactions'){
      this.router.navigateByUrl('/agentTransaction');
    }
    else if(pageName == 'Create agent account'){
      this.router.navigateByUrl('/agentCreateAcc');
    }
    else if(pageName == 'Pending payments'){
      this.router.navigateByUrl('/agentPendingPayment');
    }
    else if(pageName == 'Agent wise Balance'){
      this.router.navigateByUrl('/agentWiseBalance');
    }
    else if(pageName == 'Money Reconcilation'){
      this.router.navigateByUrl('/agentMoneyReconcil');
    }
    else if(pageName == 'Activity Log Analytics'){
      this.router.navigateByUrl('/auditActivityLog');
    }
    else if(pageName == 'Transaction report'){
      this.router.navigateByUrl('/auditTransaction');
    }
    else if(pageName == 'Service Request Report'){
      this.router.navigateByUrl('/analyticsServiceReqReport');
    }
    else if(pageName == 'BOT Survey'){
      this.router.navigateByUrl('/analyticsBOTSurvey');
    }
    else if(pageName == 'Messaging Report'){
      this.router.navigateByUrl('/MessagingReport');
    }
    else if(pageName == 'activityLog'){
      this.router.navigateByUrl('/dashboard');
    }
    else if(pageName == 'transactions'){
      this.router.navigateByUrl('/auditTransaction');
    }
    else if(pageName == 'UploadOffersAndDeals'){
      this.router.navigateByUrl('/customerOffer');
    }
    else if(pageName == 'Registration'){
      this.router.navigateByUrl('/customerAgent');
    }
    else if(pageName == 'FRS'){
      this.router.navigateByUrl('/customerFrs');
    }
    else if(pageName == 'DeviceMaster'){
      this.router.navigateByUrl('/customerDeviceMaster');
    }
    else if(pageName == 'Customer wise Balance'){
      this.router.navigateByUrl('/customerWiseBalance');
    }
    else if(pageName == 'configMasterDetails'){
      this.router.navigateByUrl('/masterConfig');
    }
    else if(pageName == 'languageJson'){
      this.router.navigateByUrl('/masterLanguage');
    }
    else if(pageName == 'locations'){
      this.router.navigateByUrl('/masterLocation');
    }
    else if(pageName == 'Donation'){
      this.router.navigateByUrl('/masterDonation');
    }
    else if(pageName == 'Wallet Upgrades'){
      this.router.navigateByUrl('/regWalletUpgrade');
    }
    else if(pageName == 'MobileUpgrade'){
      this.router.navigateByUrl('/regBranchReg');
    }
    else if(pageName == 'Services'){
      this.router.navigateByUrl('/services');
    }

    
  }
}
